﻿using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public static string Name;
        public static string Gender;
        public static string Guardian_Name;
        public static string Address;
        public static string Second_Address;
        public static string Email_id;
        public static string Mobile_no;
        public static string DOB;
        //public static string Name;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            Address = richTextBox1.Text;
        }

        private void richTextBox2_TextChanged(object sender, EventArgs e)
        {
            Second_Address = richTextBox2.Text;



        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                richTextBox2.Text = richTextBox1.Text;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Email_id = textBox3.Text.Trim();  // Make sure we capture the latest input

            if (!IsValidEmail(Email_id))
            {
                MessageBox.Show("Invalid Email Format. Please enter a valid email address.",
                                "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                textBox3.Focus();
                return; // stop submission
            }

            // ✅ If valid, proceed to show the next form
            SUBMIT frm = new SUBMIT();
            frm.Show();


        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DOB = dateTimePicker1.Value.ToString("dd-MM-yyyy");

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Name = textBox1.Text;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Guardian_Name = textBox2.Text;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Gender = radioButton1.Text;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Gender = radioButton2.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            Email_id = textBox3.Text.Trim();

            //if (!string.IsNullOrEmpty(Email_id))
            //{
            //    if (!IsValidEmail(Email_id))
            //    {
            //        MessageBox.Show("Invalid Email Format", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        textBox3.BackColor = Color.LightCoral;   
            //    }
            //    else
            //    {
            //        textBox3.BackColor = Color.LightGreen;   
            //    }
            //}
            //else
            //{
            //    textBox3.BackColor = SystemColors.Window;   
            //}
        }


        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }


        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            Mobile_no = textBox4.Text;
        }
    }
}
