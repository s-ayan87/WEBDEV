﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class SUBMIT : Form
    {
        public SUBMIT()
        {
            InitializeComponent();
        }
        private DateTime DOB;
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void SUBMIT_Load(object sender, EventArgs e)
        {


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void SUBMIT_Load_1(object sender, EventArgs e)
        {
            label10.Text = Form1.Name;
            label11.Text = Form1.Gender;
            label12.Text = Form1.Guardian_Name;
            label13.Text = Form1.Address;
            label14.Text = Form1.Second_Address;
            label15.Text = Form1.Email_id;
            label16.Text = Form1.Mobile_no;
            label17.Text = Form1.DOB;



        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }
    }
}
