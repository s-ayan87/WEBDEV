﻿namespace WinFormsApp1
{
    partial class SUBMIT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            label14 = new Label();
            label15 = new Label();
            label16 = new Label();
            label17 = new Label();
            SuspendLayout();
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(491, 399);
            label9.Name = "label9";
            label9.Size = new Size(34, 15);
            label9.TabIndex = 38;
            label9.Text = "DOB:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(48, 399);
            label8.Name = "label8";
            label8.Size = new Size(66, 15);
            label8.TabIndex = 35;
            label8.Text = "Mobile No:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(48, 242);
            label7.Name = "label7";
            label7.Size = new Size(94, 15);
            label7.TabIndex = 32;
            label7.Text = "Second Address:";
            label7.Click += label7_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(48, 109);
            label6.Name = "label6";
            label6.Size = new Size(93, 15);
            label6.TabIndex = 29;
            label6.Text = "Guardian Name:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(48, 354);
            label5.Name = "label5";
            label5.Size = new Size(52, 15);
            label5.TabIndex = 24;
            label5.Text = "Email Id:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(48, 152);
            label4.Name = "label4";
            label4.Size = new Size(52, 15);
            label4.TabIndex = 23;
            label4.Text = "Address:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(48, 73);
            label3.Name = "label3";
            label3.Size = new Size(48, 15);
            label3.TabIndex = 22;
            label3.Text = "Gender:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(48, 41);
            label2.Name = "label2";
            label2.Size = new Size(45, 15);
            label2.TabIndex = 21;
            label2.Text = "Name :";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(281, 8);
            label1.Name = "label1";
            label1.Size = new Size(178, 21);
            label1.TabIndex = 20;
            label1.Text = "ADMISSION SUCCESS !";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(179, 41);
            label10.Name = "label10";
            label10.Size = new Size(44, 15);
            label10.TabIndex = 40;
            label10.Text = "label10";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(179, 73);
            label11.Name = "label11";
            label11.Size = new Size(44, 15);
            label11.TabIndex = 41;
            label11.Text = "label11";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(184, 104);
            label12.Name = "label12";
            label12.Size = new Size(44, 15);
            label12.TabIndex = 42;
            label12.Text = "label12";
            label12.Click += label12_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(179, 152);
            label13.Name = "label13";
            label13.Size = new Size(44, 15);
            label13.TabIndex = 43;
            label13.Text = "label13";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(179, 242);
            label14.Name = "label14";
            label14.Size = new Size(44, 15);
            label14.TabIndex = 44;
            label14.Text = "label14";
            label14.Click += label14_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(178, 351);
            label15.Name = "label15";
            label15.Size = new Size(44, 15);
            label15.TabIndex = 45;
            label15.Text = "label15";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(179, 401);
            label16.Name = "label16";
            label16.Size = new Size(44, 15);
            label16.TabIndex = 46;
            label16.Text = "label16";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(595, 397);
            label17.Name = "label17";
            label17.Size = new Size(44, 15);
            label17.TabIndex = 47;
            label17.Text = "label17";
            label17.Click += label17_Click;
            // 
            // SUBMIT
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Aqua;
            ClientSize = new Size(800, 450);
            Controls.Add(label17);
            Controls.Add(label16);
            Controls.Add(label15);
            Controls.Add(label14);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "SUBMIT";
            Text = "SUBMIT";
            Load += SUBMIT_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private Label label14;
        private Label label15;
        private Label label16;
        private Label label17;
    }
}